
#include <Arduino.h>
#include "functions.h"

char recieveCharacter();

  int beginCycle = 0;
int cycleTrafficLights(){

  int timeNow = millis();
  int toReturn = 0;

  if((beginCycle + 8000) < timeNow){
    beginCycle = timeNow;
  }
if((beginCycle + 0) < timeNow && (beginCycle +1999) > timeNow){
  toReturn = 0;
}
if((beginCycle + 2000) < timeNow && (beginCycle +3999) > timeNow){
  toReturn = 1;
}
if((beginCycle + 4000) < timeNow && (beginCycle +5999) > timeNow){
  toReturn = 2;
}
if((beginCycle + 6000) < timeNow && (beginCycle +7999) > timeNow){
  toReturn = 3;
}
return toReturn;
}



void trafficLightMode(int mode){
  switch(mode){
    case 0:
      changeTrafficLight(1,1);
      changeTrafficLight(2,0);
      changeTrafficLight(3,0);
      changeTrafficLight(4,0);
    break;

    case 1:
      changeTrafficLight(1,0);
      changeTrafficLight(2,1);
      changeTrafficLight(3,0);
      changeTrafficLight(4,0);
    break;

    case 2:
      changeTrafficLight(1,0);
      changeTrafficLight(2,0);
      changeTrafficLight(3,1);
      changeTrafficLight(4,0);
    break;

    case 3:
      changeTrafficLight(1,0);
      changeTrafficLight(2,0);
      changeTrafficLight(3,0);
      changeTrafficLight(4,1);
    break;
  }
};

void changeTrafficLight(int id, int state){

switch(id){
  case 1:
  if(state ==1){
    PORTC =  PORTC | 0b01;
    PORTC =  0b010 ^ (PORTC | 0b010);
  }
  else{
    PORTC =  PORTC | 0b010;
    PORTC =  0b01 ^ (PORTC | 0b01);
  }
  break;
  case 2:
  if(state ==1){
    PORTD =  PORTD | 0b100;
    PORTD = 0b1000 ^ (PORTD | 0b1000);
  }
  else{
    PORTD =  PORTD | 0b1000;
    PORTD = 0b100 ^ (PORTD | 0b100);
  }
  break;
  case 3:
  if(state ==1){
    PORTD =  PORTD | 0b10000;
    PORTD = 0b100000 ^ (PORTD | 0b100000);
  }
  else{
    PORTD =  PORTD | 0b100000;
    PORTD = 0b10000 ^ (PORTD | 0b10000);
  }
  break;
  case 4:
  if(state ==1){
    PORTD =  PORTD | 0b1000000;
    PORTB =   0b1^ (PORTB | 0b1);
  }
  else{
    PORTB =  PORTB | 0b1;
    PORTD =  0b1000000 ^ (PORTD | 0b1000000);
  }
  break;
  default:
  break;
}

}
