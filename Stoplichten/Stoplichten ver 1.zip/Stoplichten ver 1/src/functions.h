

#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED



void changeTrafficLight(int id, int state);

char recieveCharacter();

int cycleTrafficLights();

void trafficLightMode(int mode);

#endif
